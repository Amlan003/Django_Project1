# app/forms.py
from django import forms
from django_recaptcha.fields import ReCaptchaField
from django_recaptcha.widgets import ReCaptchaV2Checkbox

class Myform(forms.Form):
    name=forms.CharField(label='Your name')
    email=forms.EmailField(label='Your email')
    message=forms.CharField(label='Your message', widget=forms.Textarea)
    captcha=ReCaptchaField(widget=ReCaptchaV2Checkbox)