from django.shortcuts import render
from django.http import HttpResponse
from.forms import Myform
# Create your views here.
def contact(request):
    if request.method =='POST':
        form=Myform(request.POST)
        
        if form.is_valid():
            cleaned_data=form.cleaned_data
            print(cleaned_data)
            form=Myform()
            return HttpResponse("Yay! you are human.")
        else:
            return HttpResponse("OOPS! Bot suspected")
        
    else:
        form=Myform()
        
        return render(request, 'index_BCT.html', {'form':form})
